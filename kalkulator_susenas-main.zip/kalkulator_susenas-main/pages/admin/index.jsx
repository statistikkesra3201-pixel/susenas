import Link from "next/link";
import React from "react";
const index = () => {
  return (
    <Link href="/" className="text-blue-500 underline">
      kembali ke beranda
    </Link>
  );
};

export default index;
